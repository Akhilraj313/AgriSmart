import { initializeApp } from "firebase/app";
import { addDoc, getFirestore } from "firebase/firestore";
import { collection, getDocs } from "firebase/firestore";
import {
  getAuth,
  RecaptchaVerifier,
  signInWithPhoneNumber,
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
} from "firebase/auth";
import { getStorage, ref, uploadBytes, getDownloadURL } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyBcjmzpHRKTt1iTIJSxdzqU-KQHlVHbdZk",
  authDomain: "agrismart-33311.firebaseapp.com",
  projectId: "agrismart-33311",
  storageBucket: "agrismart-33311.appspot.com",
  messagingSenderId: "755500564959",
  appId: "1:755500564959:web:cd2b208851efc82c81446a",
  measurementId: "G-CQ860D3MCX",
};

// Initialize Firebase
const firebaseApp = initializeApp(firebaseConfig);
const auth = getAuth(firebaseApp);

declare var window: any;

export async function SignupWithEmailAndPass(email: string, password: string) {
  const userCred = await createUserWithEmailAndPassword(auth, email, password);
  const user = userCred.user;
  return user;
}

export async function SigninWithEmailAndPass(email: string, password: string) {
  const userCred = await signInWithEmailAndPassword(auth, email, password);
  const user = userCred.user;
  return user;
}

export async function SigninWithPhoneNumber(phoneNumber: string) {
  try {
    window.recaptchaVerifier = new RecaptchaVerifier(
      "sign-in-button",
      {
        size: "invisible",
        callback: (response: any) => {
          // reCAPTCHA solved, allow signInWithPhoneNumber.
          // onSignInSubmit();
          console.log(response);
        },
      },
      auth
    );

    const appVerifier = window.recaptchaVerifier;
    const confirmationResult = await signInWithPhoneNumber(
      auth,
      phoneNumber,
      appVerifier
    );
    window.confirmationResult = confirmationResult;
  } catch (e) {
    console.error("api:: error", e);
  }
}

export async function SigninWithCode(code: string) {
  try {
    const result = await window.confirmationResult.confirm(code);
    const user = result.user;
  } catch (e) {
    /* handle error */
    console.error("api:: error", e);
  }
}

export async function api_readSensorData() {
  const db = getFirestore(firebaseApp);
  const querySnapshot = await getDocs(collection(db, "agri"));
  const data: any = [];
  querySnapshot.forEach((doc) => {
    data.push(doc.data());
  });
  console.log("data is ", data);
  return data;
}

export async function api_addItem(name: string, price: string, file: File) {
  try {
    const db = getFirestore(firebaseApp);
    const user = auth.currentUser;
    if (user) {
      const fileUrl = await api_uploadFile(file, name);
      const docRef = await addDoc(collection(db, "items"), {
        name: name,
        price: price,
        imageUri: fileUrl,
        uid: user.uid,
      });
      console.log("Document written with ID: ", docRef.id);
      console.log("user is ", user);
    } else {
      throw "Please signin";
    }
  } catch (e) {
    /* handle error */
    console.error("api::error", e);
  }
}

export async function api_getItems() {
  try {
    const db = getFirestore(firebaseApp);
    const itemsRef = await getDocs(collection(db, "items"));
    const items: any = [];
    itemsRef.forEach((doc) => items.push(doc.data()));
    return items;
  } catch (e) {
    /* handle error */
    console.error("api::error", e);
  }
}

export async function api_uploadFile(file: File, id: string) {
  try {
    const storage = getStorage();
    const fileRef = ref(storage, `images/${id}`);
    const snap = await uploadBytes(fileRef, file);
    console.log("Uploaded a blob or file!");
    const link = await getDownloadURL(snap.ref);
    console.log("got donload link", link);
    return link;
  } catch (e) {
    /* handle error */
    console.error("api::error", e);
  }
}
