const dummyData = [
  {
    id: 0,
    name: "Save Aaron",
    desc: "Help Aaron paul to fight covid 19",
  },
];

const CharityList = () => {
  return (
    <div>
      <h2>Charity List</h2>
    </div>
  );
};

export default CharityList;
