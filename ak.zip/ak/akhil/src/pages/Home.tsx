import { Button, Typography } from "@mui/material";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { api_readSensorData } from "../api/api";

const Home = () => {
  const navigate = useNavigate();

  useEffect(() => {
    api_readSensorData();
  }, []);

  return (
    <div
      style={{
        backgroundRepeat: "no-repeat",
        backgroundSize: "cover",
        backgroundImage:
          "url(https://insuranceblog.accenture.com/wp-content/uploads/2018/01/Agriculture.jpg)",
        height: "100vh",
      }}
    >
      <Typography variant="h2">AgriSmart</Typography>
      <div>
        <div
          style={{
            margin: "auto",
            width: 600,
            display: "flex",
            flexDirection: "column",
            marginTop: 50,
          }}
        >
          <Typography variant="h4">
            AgriSmart is a digital marketplace for farming.
          </Typography>
          <br />
          <br />
          <br />
          <Button variant="contained" onClick={() => navigate("/register")}>
            Join
          </Button>

          <br />
          <br />
          <Button variant="contained" onClick={() => navigate("/login")}>
            Login
          </Button>

          <br />
          <Button variant="contained" onClick={() => navigate("/sensordata")}>
            My Farm Data
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Home;
