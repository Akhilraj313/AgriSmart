import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import Login from "./pages/Login";
import CreateItem from "./pages/CreateItem";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import SensorData from "./pages/SensorData";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/login" element={<Login />} />
          <Route path="/dashboard" element={<Dashboard />} />
          <Route path="/register" element={<Register />} />
          <Route path="/createitem" element={<CreateItem />} />
          <Route path="/sensordata" element={<SensorData />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
